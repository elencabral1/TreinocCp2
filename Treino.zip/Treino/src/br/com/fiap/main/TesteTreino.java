package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Empresa;
import br.com.fiap.beans.Endereco;
import br.com.fiap.beans.Produto;


public class TesteTreino {

	public static void main(String[] args) {
		
		Empresa objEmpresa = new Empresa(JOptionPane.showInputDialog("Digite o nome"),
				JOptionPane.showInputDialog("Digite o tipo da empresa"),
				JOptionPane.showInputDialog("Digite o CNPJ"));
		
		Endereco objEndereco = new Endereco(JOptionPane.showInputDialog("Digite o logradouro"),
				Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")) ,
				JOptionPane.showInputDialog("Digite o cep"),
				JOptionPane.showInputDialog("Digite o bairro"),
				JOptionPane.showInputDialog("Digite o municipio"),
				JOptionPane.showInputDialog("Digite o estado"));
		
		Produto objProduto = new Produto(JOptionPane.showInputDialog("Digite o tipo"),
				JOptionPane.showInputDialog("Digite o marca"),
				Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade")),
				Double.parseDouble(JOptionPane.showInputDialog("Digite o valor")));
		

		objEmpresa.setEndereco(objEndereco);
		
		System.out.println("Nome da Empresa: "+ objEmpresa.getNome()+
				"\nTipo da Empresa: "+ objEmpresa.getTipo()+
				"\nCNPJ: "+ objEmpresa.getCnpj()+
				"\nLogradouro: "+ objEndereco.getLogradouro()+
				"\nNumero: "+ objEndereco.getNumero()+
				"\nCep: "+ objEndereco.getCep()+
				"\nBairro: "+ objEndereco.getBairro()+
				"\nMunicipio: "+ objEndereco.getMunicipio()+
				"\nEstado: "+ objEndereco.getEstado()+
				"\nTipo de produto: "+ objProduto.getTipo()+
				"\nMarca: "+ objProduto.getMarca()+
				"\nQuantidade: "+ objProduto.getQuantidade()+
				"\nValor: "+ objProduto.getValor());
	}

}
